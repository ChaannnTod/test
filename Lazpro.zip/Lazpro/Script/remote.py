import mysql.connector
import time
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore, Style
import os

start = time.time()

# Meminta input file dari user
file_name = input("Masukkan nama file : ")

def check_db_connection(line):
    try:
        data = line.strip().split('|')
        if len(data) < 4:
            raise ValueError('Invalid data')
        url = data[0].strip()
        database = data[1].strip()
        username = data[2].strip()
        password = data[3].strip()
        port = 3306 # default port number
        if len(data) > 4:
            host_port = data[4].strip().split(':')
            if len(host_port) > 1:
                port_str = host_port[1].strip()
                if port_str.isdigit():
                    port = int(port_str)
            host = host_port[0].strip()
        else:
            host = 'localhost'

        conn = mysql.connector.connect(
            host=host,
            port=port,
            user=username,
            password=password,
            database=database
        )

        print(Fore.GREEN + f"Connected to database {database} at {host}:{port}" + Style.RESET_ALL)
        conn.close()

        # tambahkan informasi koneksi ke file remotesqlok.txt
        with open('output/remotesqlok.txt', 'a') as outfile:
            outfile.write(f"url : {url}\n")
            outfile.write(f"dbname : {database}\n")
            outfile.write(f"dbuser : {username}\n")
            outfile.write(f"dbpass : {password}\n")
            outfile.write(f"host : {host}\n")
            outfile.write(f"port : {port}\n\n")

    except mysql.connector.Error as error:
        #  tampilkan pesan error 
        print(Fore.RED + f"Error: Can't connect to {data[1]} at {host}:{port}" + Style.RESET_ALL)
        return line
    except ValueError as error:
        return line
    return None
 

if not os.path.exists('output'):
    os.makedirs('output')

with open(file_name, 'r') as file:
    lines = file.readlines()

pool = ThreadPool(50)
results = pool.map(check_db_connection, lines)
pool.close()
pool.join()

# buat file txt kosong jika tidak ada koneksi yang berhasil
if all(r is not None for r in results):
    with open('output/remotesqlok.txt', 'w'):
        pass

print("Done, cek hasilnya di output/remotesqlok.txt")