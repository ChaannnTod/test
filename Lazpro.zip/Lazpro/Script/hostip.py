import re
import socket
from multiprocessing.dummy import Pool as ThreadPool

def process_line(line):
    match = re.search(r'^http://([^\/|]+)', line)
    if match:
        domain = match.group(1)
        try:
            ip = socket.gethostbyname(domain)
            print(f"[INFO] Success {domain} adalah {ip}")
            parts = line.split('|')
            parts[-1] = ip
            new_line = '|'.join(parts)
            return new_line
        except socket.gaierror:
            print(f"[ERROR] {domain}")
    return None

def main():
    filename = input("Enter the name of the input file: ")

    with open(filename, 'r') as file:
        lines = file.readlines()

    pool = ThreadPool(350)
    results = pool.map(process_line, lines)
    pool.close()
    pool.join()

    results = [line for line in results if line is not None]

    with open('output/listforremoteip.txt', 'w') as file:
        for line in results:
            file.write(line + "\n")

if __name__ == '__main__':
    main()
