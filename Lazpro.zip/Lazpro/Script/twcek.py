import requests
from termcolor import colored

filepath = input("Give Me Yout List: ")
with open(filepath, 'r') as file:
    keys = [line.strip() for line in file.readlines()]

for key in keys:
    sid, token = key.split(':')

    url = f'https://api.twilio.com/2010-04-01/Accounts/{sid}/Balance.json'

    response = requests.get(url, auth=(sid, token))

    if response.status_code == 200:
        balance = float(response.json().get('balance', 0))
        if balance > 0:
            with open('output/twilio.txt', 'a') as file:
                file.write(f'sid: {sid}\n')
                file.write(f'token: {token}\n')
                file.write(f'balance: {balance}\n\n')

            print(colored(f'[VALID] >> {sid} - Balance: {balance}', 'green'))
        else:
            print(f'SID: {sid} - Balance: {balance}')
    else:
        print(colored(f'[INVALID] >> {sid}', 'red'))
