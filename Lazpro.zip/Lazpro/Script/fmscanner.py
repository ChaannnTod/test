import requests
import sys
import re
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from termcolor import colored

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

print("==============================================")
print(colored("   FileMangerHunt (By Haxor1337)        ",'green'))
print(colored(" >> https://github.com/haxor1337x/ <<      ",'green'))
print("==============================================")

path_file = input("Give List Your Path (Ready Path At Folter [/Path/]: ")
with open(path_file, "r") as f:
    paths = f.readlines()

listpath = input("Give List Your List: ")
op = ["http://" + i.strip() for i in open(listpath, "r").readlines()]

def check(site):
    for path in paths:
        try:
            r = requests.get(site + path.strip(), verify=False, timeout=10)
            if '<h1 class="panel-title">Laravel FileManager</h1>' in r.text or "alert('Unknown error')" in r.text or '{"files":[{"name":"' in r.text or '<title>Responsive FileManager</title>' in r.text:
                print(colored(f"Found  ->  {site}{path.strip()}", 'green'))
                with open("output/fmvuln.txt", "a+") as ff:
                    ff.write(f"{site}{path.strip()}\n")
            else:
                print(colored(f"Not Found -> {site}{path.strip()}", 'red'))
        except Exception as e:
            print(colored(f"Unknown Error -> {site}{path.strip()}", 'yellow'))

with Pool(200) as tod:
    tod.map(check, op)
