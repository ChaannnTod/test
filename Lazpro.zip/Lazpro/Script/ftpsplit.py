import requests
import re
import concurrent.futures
import multiprocessing
import sys

def parse_url(url):
    try:
        response = requests.get(url)
        text = response.text
        host_pattern = r'"host"\s*:\s*"([^"]*)"|' \
                       r'"host":\s+"([^"]+)"'
        username_pattern = r'"username"\s*:\s*"([^"]*)"|' \
                           r'"user":\s+"([^"]+)"'
        password_pattern = r'"password"\s*:\s*"([^"]*)"|' \
                           r'"password":\s+"([^"]+)"'
        port_pattern = r'"port"\s*:\s*(\d+)|' \
                       r'"port":\s+"([^"]+)"'

        host_match = re.search(host_pattern, text)
        username_match = re.search(username_pattern, text)
        password_match = re.search(password_pattern, text)
        port_match = re.search(port_pattern, text)

        if not port_match:
            port = 21
        else:
            port = port_match.group(1) or port_match.group(2)

        if all([host_match, username_match, password_match]):
            host = host_match.group(1) or host_match.group(2)
            username = username_match.group(1) or username_match.group(2)
            password = password_match.group(1) or password_match.group(2)

            with open("output/readyforftp.txt", "a") as f:
                f.write("{}|{}|{}|{}|{}\n".format(url, host, port, username, password))

            return True
        else:
            return False

    except requests.exceptions.RequestException:
        return False

if __name__ == "__main__":
    with open("output/sftpfound.txt", "r") as f:
        lines = f.readlines()

    with open("output/readyforftp.txt", "w") as f:
        f.write("")

    num_cpus = multiprocessing.cpu_count()
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_cpus) as executor:
        futures = []
        for line in lines:
            url = line.strip()
            futures.append(executor.submit(parse_url, url))

        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            if future.result():
                print("Mengambil Data {} dari {}".format(i, len(lines)))
            else:
                print("Data Not Found {} dari {}".format(i, len(lines)))

    with open("output/readyforftp.txt", "r") as f:
        lines = f.readlines()
    print("Done Split Ftp/Sftp/Ssh")
