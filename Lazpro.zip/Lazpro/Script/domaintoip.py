import socket
import multiprocessing
import colorama
from colorama import Fore, Style

def get_ip(domain):
    try:
        ip = socket.gethostbyname(domain)
        print(Fore.GREEN + f'[SUCCESS] {domain} >> {ip}')
        with open('output/ip.txt', 'a') as f:
            f.write(f'{ip}\n')
        return domain, ip
    except:
        print(Fore.RED + f'[FAILED] {domain}')
        return domain, None

if __name__ == '__main__':
    filename = input('Masukkan nama file: ')
    with open(filename, 'r') as f:
        domains = [line.strip() for line in f.readlines()]
    num_processes = 50
    domains_split = [domains[i:i+num_processes] for i in range(0, len(domains), num_processes)]
    colorama.init()
    with multiprocessing.Pool(num_processes) as pool:
        results = pool.map(get_ip, domains)

    print(Style.RESET_ALL + 'Selesai! Hasilnya disimpan di file output/ip.txt.')
